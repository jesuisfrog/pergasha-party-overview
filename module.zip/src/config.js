const config = {
  name: "Pergasha Party Overview",
  version: "1.0.0",
};

export default config;
